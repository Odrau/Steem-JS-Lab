Post By Author - Embeddable Links
Written By @Odrau (Robert Parent) 2018

==File Info==
PBA (post by author) This tool allows you to get previous posts by specified author and
applies different Steem compatible HTML formats. You can then include the code in your 
future Steem posts! Having links to your previous post will help foster engagement and 
will help you gain a larger audience. So this is super useful and Important! Additionally, 
there are some methods to filter the results, via Category, Tags, or a Regex search within
the Title or Body of a post.

If these tools help you by saving you time and making your content better/more engaging,
please consider donating to the developer.

These jobs are often extrememly time consuming and go with little notice or thanks. 
All donations will help me out and incentivise future developments.

You can send Steem/SBD donations on Steem to @Odrau https://steemit.com/@odrau

	Litecoin: LaTxKZTo1CjZsQBDJPyCbHVgcuZJnsHsHQ
	Bitcoin: 1PE8M2yJvvrMTiNHWSpVQ2ZKFhad13mWn5
	Etherium: 0x511EEc68FC2d727E4133aFd648Dd9d8520802CcE

Thank You

